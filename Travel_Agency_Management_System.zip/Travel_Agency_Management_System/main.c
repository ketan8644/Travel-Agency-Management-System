#include<stdio.h>
#include <stdlib.h>
#include "conio2.h"
#include<string.h>
#include"Travel.h"

int main()
{
    gotoxy(30,10);
    textcolor(YELLOW);
    printf("SATYAM TRAVEL AGENCY");
    gotoxy(20,13);
    textcolor(LIGHTGREEN);
    printf("* RENT A CAR AND GO WHEREVER YOU NEED *");
    _getch();
    textcolor(YELLOW);
    addAdmin();
    User *usr;
    int result;
    int choice;
    int i;
    while(1)
        {
        		clrscr();
       	     textcolor(LIGHTRED);
        	    gotoxy(32,2);
       	   printf("SATYAM TRAVEL AGENCY");
       	  //upper line
        	gotoxy(1,8);
        	textcolor(YELLOW);
        	for(i=0; i<80; i++)
            	 printf("*");
        	//lower line
        	gotoxy(1,17);
        	for(i=0; i<80; i++)
            	printf("*");
            	int k;
            do
            {
             usr=getInput();
             if(usr!=NULL)
            {
                        									//code for validating userid and password
            k=checkUserExist(*usr, "admin");
            }
             else
            {
            break;
            }
            }
    while(k==0);
                    if(k==1)
                 {

                    gotoxy(30,14);
                    textcolor(GREEN);
                    printf("Login Accepted!");
                    gotoxy(1,20);
                    printf("Press any key to continue");
                    _getch();


                while(1){

                    clrscr();
                    choice=adminMenu();
                    if(choice==7){
                        clrscr();
                        break;
                    }

                    switch(choice){

                        case 1:
                            clrscr();
                            addCarDetails();
                            break;
                        case 2:
                            clrscr();
                            showCarDetails();
                            break;
                        case 3:
                            clrscr();
                            result=deleteCarModel();
                            if(result==0){
                                gotoxy(15,14);
                                printf("Sorry! No Car Found with the given Car ID");
                                printf("\n\nPress Any Key to go back to the Main Menu");
                                _getch();
                            }
                            else if(result==1){
                                gotoxy(25,14);
                                textcolor(GREEN);
                                printf("Record Deleted Successfully");
                                printf("\n\nPress Any Key to go Back to the Main Menu");
                                _getch();

                            }
                        case 4:
                        clrscr();
                        int j;
                        do{

                            clrscr();
                            j=rentCar();
                            if(j==0)
                                printf("Booking Cancelled\nTry Again");
                            _getch();
                        }while(j==0);
                        _getch();
                        break;
                        case 5:
                        clrscr();
                        bookedCarDetails();
                        _getch();
                        break;
                       case 6:
                        clrscr();
                        availableCarDetails();
                        break;

                        default:
                            printf("Invalid Input");
                            _getch();

                    } //Switch Close

                }


}

}
return 0;
}







