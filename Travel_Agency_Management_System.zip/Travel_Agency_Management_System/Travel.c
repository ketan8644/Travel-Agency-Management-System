#include<stdio.h>
#include <stdlib.h>
#include "conio2.h"
#include<string.h>
#include"Travel.h"



void addAdmin()
{
    FILE *fp=fopen("admin.bin","rb");
    if(fp==NULL)
    {
        fp=fopen("admin.bin","wb");
        User u[1]= {{"ketan","abc","Ramesh"},{"aftab", "abc", "Md Aftab Ahmad"}};
        fwrite(u,sizeof(u),1,fp);
        fclose(fp);
        _getch();
    }
    else
    {
        fclose(fp);

    }
}


User *getInput()
{

    int i;
    clrscr();
    textcolor(YELLOW);
    gotoxy(32,1);
    printf("SATYAM TRAVEL AGENCY\n");
    for(i=1; i<=80; i++)
        printf("%c",247);
    gotoxy(32,5);
    printf("* LOGIN PANEL *");
    gotoxy(1,7);
    textcolor(LIGHTCYAN);
    for(i=1; i<80; i++)
        printf("%c",247);
    gotoxy(1,15);
    for(i=1; i<80; i++)
        printf("%c",247);
    gotoxy(25,10);
    textcolor(LIGHTCYAN);
    printf("Enter user id:");
    fflush(stdin);
    textcolor(WHITE);
    static User usr;
    fgets(usr.userid,20,stdin);
    char *pos;
    pos=strchr(usr.userid,'\n');
    *pos='\0';
    gotoxy(25,11);
    textcolor(LIGHTCYAN);
    printf("Enter Password:");
    fflush(stdin);
    i=0;
    textcolor(WHITE);
    for(;;)
    {
        usr.pwd[i]=_getch();
        if(usr.pwd[i]=='\n'){
                break;
            }
            else if(usr.pwd[i]==127 || usr.pwd[i]=='\b'){
                printf("\b \b");
                i-=2;
                continue;
            }
            else
            printf("*");

            if ( usr.pwd[i]=='\r')
            break;
        i++;
    }
    usr.pwd[i]='\0';
    if(strcmp(usr.pwd,"0")==0)
    {
        textcolor(LIGHTRED);
        gotoxy(30,17);
        printf("Login Cancelled!");
        _getch();
        textcolor(YELLOW);
        return NULL;
    }
    return &usr;

}

int checkUserExist(User u,char *usertype)
{
    if(strcmp(u.userid,"")==0 || strcmp(u.pwd,"")==0)
        {
            gotoxy(28,20);
            textcolor(LIGHTRED);
            printf("BOTH FIELDS ARE MANDATORY");
            _getch();
            gotoxy(28,20);
            printf("\t\t\t\t\t\t\t\t\t");
            return 0;
 }
    int found=0;
    if(!(strcmp(usertype,"admin")))
    {
       FILE *fp=fopen("admin.bin","rb");
        User user;
        while(fread(&user,sizeof(User),1,fp)==1)
        {
            if(strcmp(u.userid,user.userid)==0 && strcmp(u.pwd,user.pwd)==0 )
            {
                found=1;
                break;
            }
        }
        if(!found)
        {
            gotoxy(27,20);
            textcolor(LIGHTRED);
            printf("INVALID USERID OR PASSWORD");
            _getch();
            fclose(fp);
            return 0;
        }
        fclose(fp);
    }

  return 1;
}
int adminMenu()
{
    int choice,i;
    textcolor(LIGHTRED);
    gotoxy(32,2);
    printf("SATYAM TRAVEL AGENCY");
    textcolor(LIGHTGREEN);
    gotoxy(35,6);
    printf("MENU\n");
    for(i=0; i<80; i++)
    {
        printf("*");
    }
    textcolor(YELLOW);
    gotoxy(32,8);
    printf("1. Add Car Details");
    gotoxy(32,9);
    printf("2. Show Car Details");
    gotoxy(32,10);
    printf("3. Delete Car Details");
    gotoxy(32,11);
    printf("4. Rent A Car");
    gotoxy(32,12);
    printf("5. Booking Details");
    gotoxy(32,13);
    printf("6. Available Car Details");
    gotoxy(32,14);
    printf("7. Exit");
    gotoxy(32,16);
    printf("Enter choice:");
    textcolor(WHITE);
    scanf("%d",&choice);
    return choice;
}

void addCarDetails(){

         FILE *fp=fopen("car.bin", "rb");
    int id=1;
    char uchoice;
    car c1,c2;

    if(fp==NULL){

        fp=fopen("car.bin", "ab");
        id=1;
        c1.car_id=id;


    }

    else{

        fp=fopen("car.bin", "ab+");
        fseek(fp, -1L*sizeof(c1), SEEK_END);
        fread(&c2, sizeof(c2), 1, fp);
        id=c2.car_id;
        printf("%d",id);
        id++;
        c2.car_id=id;
        c1.car_id=c2.car_id;

    }


    do{

        clrscr();
        c1.car_id=id;
        gotoxy(32,2);
        textcolor(RED);
        printf("CAR RENTAL APP");
        int i;
        gotoxy(1,3);
        for(i=0; i<80; i++)
            printf("~");
        gotoxy(25, 5);
        printf("***** ADD CAR DETAILS ******");
        gotoxy(1,8);
        textcolor(LIGHTCYAN);
        printf("Enter Car Name :");
        fflush(stdin);
        fgets(c1.car_name, 50, stdin);
        char *pos;
        pos=strchr(c1.car_name, '\n');
        *pos='\0';
        textcolor(LIGHTCYAN);
        printf("Enter Capacity:");
        fflush(stdin);
        scanf("%d",&c1.capacity);
        textcolor(LIGHTCYAN);
        printf("Enter Number of Car:");
        scanf("%d",&c1.car_count);
        textcolor(LIGHTCYAN);
        printf("Enter Price:");
        scanf("%d",&c1.price);
        fseek(fp, 0, SEEK_END);
        fwrite(&c1, sizeof(car), 1,fp);
        gotoxy(30,15);
        textcolor(LIGHTCYAN);
        printf("CAR ADDED SUCCESSFULLY");
        printf("\n CAR ID IS: %d",c1.car_id);
        _getch();
        gotoxy(1,20);
        textcolor(LIGHTCYAN);
        printf("DO YOU WANT TO ADD MORE CAR (Y/N)  : ");
        fflush(stdin);
        scanf("%c", &uchoice);
        id++;
        c1.car_id=id;

         }while(uchoice=='Y' || uchoice=='y');

    fclose(fp);
}

void showCarDetails(){

        FILE *fp=fopen("car.bin", "rb");
    car ur;
    int i;
    gotoxy(32,1);
    textcolor(RED);
    printf("CAR RENTAL SYSTEM\n");
    for(i=1; i<=80; i++)
        printf("*");
    gotoxy(31,5);
    textcolor(YELLOW);
    printf("* CAR DETAILS *");
    gotoxy(1,7);
    for(i=0; i<=80; i++)
        printf("*");
    gotoxy(1,8);
    printf(" CAR ID\t\tName\t\tCapacity\tNumber\t\tPrice");
    gotoxy(1,9);
    for(i=1;i<=80; i++)
        printf("*");
        int x=10;
        while(fread(&ur, sizeof(ur), 1,fp) == 1)
        {
            gotoxy(5,x);
            printf("%d", ur.car_id);
            gotoxy(17,x);
            printf("%s", ur.car_name);
            gotoxy(35, x);
            printf("%d", ur.capacity);
            gotoxy(50, x);
            printf("%d", ur.car_count);
            gotoxy(65, x);
            printf("%d", ur.price);
            x++;
        }

        _getch();
        fclose(fp);
        _getch();
}

int deleteCarModel(){

FILE *fp1=fopen("car.bin", "rb");

int id,i;

gotoxy(32,1);
textcolor(RED);
    printf("CAR RENTAL SYSTEM\n");
    for(i=1; i<=80; i++)
        printf("*");
    gotoxy(29,5);
    textcolor(BLUE);
    printf("* DELETE CAR RECORD *");
    gotoxy(1,7);
    for(i=1; i<=80; i++)
        printf("*");
    gotoxy(1,12);
    for(i=1; i<80; i++)
        printf("*");
    if(fp1==NULL){

        textcolor(RED);
        printf("\nNo Car Added Yet!");
        return -1;

    }

    FILE *fp2=fopen("temp.bin", "wb+");
    gotoxy(10,9);
    textcolor(YELLOW);
    printf("Enter Car ID to Delete the Record:");
    scanf("%d",&id);

    car U;
    int found=0;
    while(fread(&U, sizeof(U), 1, fp1)==1){

        if(U.car_id!=id){
            fwrite(&U, sizeof(U), 1, fp2);
        }
        else{
            found=1;
        }

    }

    fclose(fp1);

    if(found==1){

        rewind(fp2);
        fp1=fopen("car.bin", "wb");
        while(fread(&U, sizeof(U), 1, fp2) ==1){
            fwrite(&U, sizeof(U), 1,fp1);
        }
        fclose(fp1);

    }

    fclose(fp2);
    remove("temp.bin");
    return found;

}

int selectCarModel(){

int flag=0;
FILE *fp=fopen("car.bin", "rb");
car C;
int choice,x=9;
gotoxy(34,x);
while(fread(&C, sizeof(C), 1,fp)==1){

    if(C.car_count>0){
        printf("%d . %s", C.car_id,C.car_name);
        gotoxy(34,++x);

    }
}

    gotoxy(34, x+2);
    printf("Enter Your Choice:");

    while(1){

        flag=0;
        scanf("%d",&choice);
        rewind(fp);

        while(fread(&C, sizeof(C), 1, fp)==1){

            if(C.car_id==choice && C.car_count>0){

                flag=1;
                break;
            }
        }

        if(flag==1){

            fclose(fp);
            return choice;
        }

        else{

            gotoxy(37, x+4);
            textcolor(RED);
            printf("Wrong Input");
            _getch();
            gotoxy(35, x+4);
            printf("\t\t");
            gotoxy(52, x+2);
            printf("\t");
            gotoxy(52, x+2);

        }
    }

}


int isValidDate(struct tm dt){

    if(dt.tm_year>=2020 && dt.tm_year<=2022){

        if(dt.tm_mon>=1 && dt.tm_mon<=12){

            if((dt.tm_mday>=1 && dt.tm_mday<=31) && (dt.tm_mon==1 || dt.tm_mon==3 || dt.tm_mon==5 || dt.tm_mon==7 || dt.tm_mon==8 || dt.tm_mon==10 || dt.tm_mon==12))
                return 1;
            else if((dt.tm_mday>=1 && dt.tm_mday<=30) && (dt.tm_mon==4 || dt.tm_mon==6 || dt.tm_mon==9 || dt.tm_mon==11))
                return 1;
            else if((dt.tm_mday>=1 && dt.tm_mday<=28) && (dt.tm_mon==2))
                return 1;
            else if(dt.tm_mday==29 && dt.tm_mon==2 && (dt.tm_year%400==0 || (dt.tm_year%4==0 && dt.tm_year%100!=0)))
                return 1;

            else
                return 0;

        }

        else {

            return 0;
        }

    }

    else{

        return 0;
    }
}

void updateCarCount(int c){

    FILE *fp=fopen("car.bin" , "rb+");
    car C;
    while(fread(&C, sizeof(car), 1, fp)==1){

        if(C.car_id==c){

            fseek(fp, -8, SEEK_CUR);
            int cc_new=C.car_count-1;
            printf("%d",C.car_count);
            printf("%d",cc_new);
            fwrite(&cc_new, sizeof(cc_new), 1, fp);
        }
    }
    fclose(fp);
}


char* getCarName(int car_id){

        FILE *fp=fopen("car.bin" , "rb");
        static car C;

        while(fread(&C, sizeof(C), 1, fp) ==1){

            if(C.car_id==car_id){
                break;
            }
        }

        fclose(fp);
        return C.car_name;
}



void availableCarDetails(){

 static int a,b,I,s,r=0;
        int i=0;  int x=10;
    FILE *fp=fopen("customer.bin" , "rb");
     FILE *fp1=fopen("car.bin", "rb");
     car ur;
    Customer_Car_Details CC;
    while(fread(&CC, sizeof(Customer_Car_Details), 1, fp)==1){

            if(strcmp(getCarName(CC.car_id),"Audi")==0){
                a++;
                printf("a = %d\n",a);

            }

             if(strcmp(getCarName(CC.car_id),"BMW")==0){
                b++;
                printf("b= %d\n",b);
            }

             if(strcmp(getCarName(CC.car_id),"i10")==0){
                I++;
                printf("I= %d\n",I);
            }

             if(strcmp(getCarName(CC.car_id),"Swift")==0){
                s++;
                printf("s = %d\n",s);
            }

            if(strcmp(getCarName(CC.car_id),"Royal")==0){
                r++;
                printf("r= %d\n",r);
            }

    }


    clrscr();
    gotoxy(32,1);
    textcolor(RED);
    printf("CAR RENTAL SYSTEM\n");
    for(i=1; i<=80; i++)
        printf("*");
    gotoxy(31,5);
    textcolor(YELLOW);
    printf("* CAR DETAILS *");
    gotoxy(1,7);
    for(i=0; i<=80; i++)
        printf("*");
    gotoxy(1,8);
    printf(" CAR ID\t\tName\t\tCapacity\tNumber\t\tPrice");
    gotoxy(1,9);
    for(i=1;i<=80; i++)
        printf("*");

        while(fread(&ur, sizeof(ur), 1,fp1) == 1)
        {
            gotoxy(5,x);
            printf("%d", ur.car_id);
            gotoxy(17,x);
            printf("%s", ur.car_name);
            gotoxy(35, x);
            printf("%d", ur.capacity);
            gotoxy(50, x);

             if(ur.car_id==1){
                ur.car_count=ur.car_count-a;
                printf("%d", ur.car_count);
                a-=a;

            }

             if(ur.car_id==2){
                ur.car_count=ur.car_count-b;
                printf("%d", ur.car_count);
                b-=b;
            }

            if(ur.car_id==3){
                ur.car_count=ur.car_count-I;
                printf("%d", ur.car_count);
                I-=I;
            }

            if(ur.car_id==4){
                ur.car_count=ur.car_count-s;
                printf("%d", ur.car_count);
                s-=s;

            }

            if(ur.car_id==5){
                ur.car_count=ur.car_count-r;
                printf("%d", ur.car_count);
                r-=r;
            }

            gotoxy(65, x);
            printf("%d", ur.price);
            x++;
        }


        _getch();
        fclose(fp1);
        _getch();
}







void bookedCarDetails()
{

    clrscr();
    FILE *fp=fopen("customer.bin" , "rb");
    Customer_Car_Details CC;
    int i;
    gotoxy(32,1);
    textcolor(RED);
    printf("CAR RENTAL SYSTEM\n");
    for(i=1; i<=79; i++)
        printf("*");
    gotoxy(32,5);
    textcolor(BLUE);
    printf("* BOOKED CAR DETAILS *");
    gotoxy(1,7);
    for(i=1; i<=79;i++)
        printf("*");
    gotoxy(1,8);
    printf("Model\t  Cust Name\t   Pick Up\t   Drop\t\t  S_Date\t  E_Date");
    gotoxy(1,9);
    for(i=1; i<=79;i++)
        printf("*");
    int x=10;
    printf("\n\n");
    while(fread(&CC, sizeof(Customer_Car_Details), 1, fp)==1){

        gotoxy(1,x);
        printf("%s",getCarName(CC.car_id));
        gotoxy(13,x);
        printf("%s", CC.cust_name);
        gotoxy(27,x);
        printf("%s",CC.pick);
        gotoxy(44,x);
        printf("%s",CC.drop);
        gotoxy(58,x);
        printf("%d/%d/%d",CC.sd.tm_mday, CC.sd.tm_mon, CC.sd.tm_year);
        gotoxy(70,x);
        printf("%d/%d/%d",CC.ed.tm_mday, CC.ed.tm_mon, CC.ed.tm_year);
        x++;

    }

    fclose(fp);
    _getch();
}

int rentCar()
{

    Customer_Car_Details CC;
    char pick[30], drop[30];
    int c,i;
    gotoxy(32,2);
    textcolor(RED);
    printf("CAR RENTAL SYSTEM");
    gotoxy(35,6);
    textcolor(YELLOW);
    printf("EMPLOYEE MENU\n");
    for(i=0;i<80;i++)
        printf("*");
    gotoxy(32,8);
    c=selectCarModel();
    CC.car_id=c;
    clrscr();

    gotoxy(32,2);
    textcolor(RED);
    printf("CAR RENTAL SYSTEM");
    gotoxy(35,6);
    textcolor(GREEN);
    printf("EMPLOYEE MENU\n");
    for(i=0;i<79;i++)
        printf("*");
    gotoxy(1,17);
    for(i=0;i<80;i++)
        printf("*");
    gotoxy(27,9);
    textcolor(BLUE);
    printf("Enter Customer Name:");
    fflush(stdin);
    fgets(CC.cust_name,30,stdin);
    char *pos;
    pos=strchr(CC.cust_name,'\n');
    *pos='\0';
    gotoxy(27,10);
    textcolor(BLUE);
    printf("Enter Pickup Point:");
    fflush(stdin);
    fgets(CC.pick,30,stdin);
    pos=strchr(CC.pick,'\n');
    *pos='\0';
    gotoxy(27,11);
    textcolor(BLUE);
    printf("Enter Drop Point:");
    fflush(stdin);
    fgets(CC.drop,30,stdin);
    pos=strchr(CC.drop,'\n');
    *pos='\0';
    gotoxy(27,12);
    textcolor(BLUE);
    printf("Enter Start Date (dd/m/yyyy):");

    do{

        scanf("%d/%d/%d",&CC.sd.tm_mday,&CC.sd.tm_mon,&CC.sd.tm_year);
        int datevalid=isValidDate(CC.sd);

        if(datevalid==0){
            gotoxy(27,18);
            textcolor(RED);
            printf("Wrong Date");
            _getch();
            gotoxy(27,18);
            printf("\b\b\b");
            gotoxy(56,12);
            printf("\b\b\b");
            gotoxy(56,12);

        }

        else
            break;

    }while(1);

    gotoxy(27,13);
    textcolor(BLUE);
    printf("Enter End Date (dd/m/yyyy):");

    do{

         scanf("%d/%d/%d",&CC.ed.tm_mday,&CC.ed.tm_mon,&CC.ed.tm_year);
        gotoxy(56,13);
          if(CC.ed.tm_mday>=CC.sd.tm_mday){

                if(CC.ed.tm_mon>=CC.sd.tm_mon){


                        if(CC.ed.tm_year>=CC.sd.tm_year){

                int datevalid=isValidDate(CC.ed);
                if(datevalid==0){

            gotoxy(27,18);
            textcolor(RED);
            printf("Wrong Date !!!");
            _getch();
            _getch();
            gotoxy(27,18);
            textcolor(RED);
            printf("Please Try Again !! ");
            _getch();
            gotoxy(27,18);
            printf("\t\t\t\t");
            gotoxy(54,13);
            printf("\t\t\t\t");
            gotoxy(54,13);

        }
                else
                break;



                        }

                         else
          {
            gotoxy(27,18);
            textcolor(RED);
            printf("Wrong Date !!!");
            _getch();
            _getch();
            gotoxy(27,18);
            textcolor(RED);
            printf("Please Try Again !! ");
            _getch();
            gotoxy(27,18);
            printf("\t\t\t\t");
            gotoxy(54,13);
            printf("\t\t\t\t");
            gotoxy(54,13);
          }

                }

               else
          {
            gotoxy(27,18);
            textcolor(RED);
            printf("Wrong Date !!!");
            _getch();
            _getch();
            gotoxy(27,18);
            textcolor(RED);
            printf("Please Try Again !! ");
            _getch();
            gotoxy(27,18);
            printf("\t\t\t\t");
            gotoxy(54,13);
            printf("\t\t\t\t");
            gotoxy(54,13);
          }

          }
          else
          {
            gotoxy(27,18);
            textcolor(RED);
            printf("Wrong Date !!!");
            _getch();
            _getch();
            gotoxy(27,18);
            textcolor(RED);
            printf("Please Try Again !! ");
            _getch();
            gotoxy(27,18);
            printf("\t\t\t\t");
            gotoxy(54,13);
            printf("\t\t\t\t");
            gotoxy(54,13);
          }

    }while(1);


    FILE *fp=fopen("customer.bin" , "ab");
    fwrite(&CC, sizeof(Customer_Car_Details), 1, fp);
    printf("\nPress any key to Continue ...");
    _getch();
    _getch();
    fclose(fp);
    updateCarCount(c);
    bookedCarDetails();

    return 1;


}




